import base64
import gzip
import hashlib
import http.cookiejar
import json
import os
import re
import sqlite3
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, unquote, urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPCookieProcessor

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

addon = xbmcaddon.Addon()
ADDON_PATH = addon.getAddonInfo("path")
DB_PATH = os.path.join(ADDON_PATH, "rezka_database.db")
CACHE_PATH = os.path.join(ADDON_PATH, "rezka_url_cache.json")

BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])

_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)
_QUALITY_ORDER = ["1080p", "720p", "480p", "360p", "auto"]

_cookie_jar = http.cookiejar.CookieJar()
_opener = build_opener(HTTPCookieProcessor(_cookie_jar))

# ── Network / rezka helpers ───────────────────────────────────────────────────

_DEFAULT_REZKA_DOMAIN = "https://rezka.ag"


def _domain_of(url):
    """Return scheme://host for a URL, e.g. 'https://hdrezka-home.tv'."""
    parts = urlsplit(url)
    return f"{parts.scheme}://{parts.netloc}" if parts.netloc else _DEFAULT_REZKA_DOMAIN


def _headers_for(referer_url):
    """Base request headers with the Referer set to the given page's own domain,
    so a mirror stored in rezka_database.json (e.g. hdrezka-home.tv) is used
    consistently instead of always pointing back at rezka.ag."""
    return {
        "User-Agent": _UA,
        "Referer": referer_url,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate",
    }


def _read_response(resp):
    with resp as r:
        raw = r.read()
        enc = r.headers.get("Content-Encoding", "")
        if enc == "gzip":
            raw = gzip.decompress(raw)
        elif enc == "deflate":
            import zlib
            raw = zlib.decompress(raw)
        return raw.decode("utf-8", errors="replace")


_GATEWAY_RETRY_CODES = (502, 503, 504)


def _open_with_gateway_retry(req, timeout, attempts=3, delay=2):
    """Open a request, retrying on transient failures from rezka.ag's Anubis
    anti-bot proxy: gateway errors (502/503/504) and bare connection resets,
    both of which it produces under load far more often than a real block."""
    for attempt in range(attempts):
        try:
            return _opener.open(req, timeout=timeout)
        except HTTPError as e:
            if e.code not in _GATEWAY_RETRY_CODES or attempt == attempts - 1:
                raise
            xbmc.log(
                f"RezkaLocal: {e.code} от {req.full_url}, повтор {attempt + 1}/{attempts - 1}",
                xbmc.LOGWARNING,
            )
            time.sleep(delay)
        except URLError as e:
            if not isinstance(e.reason, ConnectionError) or attempt == attempts - 1:
                raise
            xbmc.log(
                f"RezkaLocal: соединение оборвано [{req.full_url}], повтор {attempt + 1}/{attempts - 1}",
                xbmc.LOGWARNING,
            )
            time.sleep(delay)


def _solve_anubis(html, url):
    """
    Solve Anubis PoW challenge and return the real page content.
    Algorithm 'fast': find nonce where sha256(randomData + str(nonce))
    has the first floor(difficulty/2) bytes == 0x00, and if difficulty is odd
    the high nibble of byte floor(difficulty/2) must also be 0.
    """
    m = re.search(r'id="anubis_challenge"[^>]*>(\{.*?\})\s*</script>', html, re.DOTALL)
    if not m:
        return None
    wrap = json.loads(m.group(1))
    ch = wrap["challenge"]

    m2 = re.search(r'id="anubis_base_prefix"[^>]*>"([^"]*)"', html)
    base_prefix = m2.group(1) if m2 else ""

    difficulty = ch["difficulty"]
    p = difficulty // 2
    u = difficulty % 2 != 0
    random_data = ch["randomData"]

    nonce = 0
    while True:
        digest = hashlib.sha256((random_data + str(nonce)).encode()).digest()
        ok = all(digest[i] == 0 for i in range(p))
        if ok and u and (digest[p] >> 4) != 0:
            ok = False
        if ok:
            break
        nonce += 1

    params = urlencode({
        "id": ch["id"],
        "response": digest.hex(),
        "nonce": str(nonce),
        "redir": url,
        "elapsedTime": "1337",
    })
    submit_url = f"{_domain_of(url)}{base_prefix}/.within.website/x/cmd/anubis/api/pass-challenge?{params}"
    req = Request(submit_url, headers=_headers_for(url))
    return _read_response(_open_with_gateway_retry(req, timeout=20))


_seeded_cookie_domains = set()

# Cookies a real browser carries on every rezka request. Not required to
# render the page, but the CDN stream API (get_cdn_series) treats a client
# missing them as a bare anonymous request and can reject it outright
# (observed as a generic "Время сессии истекло" error) rather than serving
# the stream — passing translator_id/content_id alone isn't enough.
_BROWSER_COOKIES = (
    ("allowed_comments", "1"),
    ("_ym_isad", "1"),
    ("_ym_visorc", "b"),
    ("dle_newpm", "0"),
)


def _seed_browser_cookies(domain):
    if domain in _seeded_cookie_domains:
        return
    _seeded_cookie_domains.add(domain)
    host = urlsplit(domain).hostname
    if not host:
        return
    for name, value in _BROWSER_COOKIES:
        _cookie_jar.set_cookie(http.cookiejar.Cookie(
            version=0, name=name, value=value,
            port=None, port_specified=False,
            domain=host, domain_specified=True, domain_initial_dot=False,
            path="/", path_specified=True,
            secure=False, expires=None, discard=True,
            comment=None, comment_url=None, rest={},
        ))


def _fetch(url):
    _seed_browser_cookies(_domain_of(url))
    req = Request(url, headers=_headers_for(url))
    html = _read_response(_open_with_gateway_retry(req, timeout=15))
    if "anubis_challenge" in html:
        real = _solve_anubis(html, url)
        if real:
            html = real
    return html


def _parse_translator_links(html):
    """Return {display_name: (translator_id, href)} for the REAL translator
    links on a rezka page.

    rezka also renders a decoy list right before the real one: same names
    and data-translator_id values, but styled 'b-translator__items' —
    plural, note the trailing s — hidden via a `{display:none}` rule, and
    pointing at bogus obfuscated-slug URLs. It exists to catch scrapers
    that follow every link with a data-translator_id rather than reading
    the page like a browser does. Matching the class name exactly
    ('b-translator__item', optionally '... active') skips those and keeps
    only the real, visible entries."""
    result = {}
    for m in re.finditer(
        r'<a[^>]+title="([^"]+)"[^>]+class="b-translator__item(?: active)?"'
        r'[^>]+data-translator_id="(\d+)"[^>]+href="([^"]+)"',
        html,
    ):
        name, tid, href = m.groups()
        name = name.strip().replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        if name and name not in result:
            result[name] = (tid, href)
    return result


def _parse_movie_translator_ids(html):
    """Return {display_name: (translator_id, is_active)} for movie-style
    translator entries, which — unlike series ones — carry no href at all:

        <li title="Дубляж" class="b-translator__item active"
            data-id="302" data-translator_id="56" ...>Дубляж</li>

    A movie has no season/episode to combine a translator with, so rezka
    switches translator in place via JS/AJAX rather than linking to a
    separate page per translator — there's simply no URL to extract here
    for anything but the one already showing (is_active)."""
    result = {}
    for m in re.finditer(
        r'<li[^>]+title="([^"]+)"[^>]+class="b-translator__item( active)?"'
        r'[^>]+data-translator_id="(\d+)"',
        html,
    ):
        name, active, tid = m.groups()
        name = name.strip().replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        if name and name not in result:
            result[name] = (tid, bool(active))
    return result


def _extract_cdn_config(html, expected_id=None):
    """Stream URLs are baked directly into the page's own player-init call —
    sof.tv.initCDNMoviesEvents(id, ...)/initCDNSeriesEvents(id, ..., config)
    — as its trailing JSON object argument. rezka apparently stopped
    resolving streams via the /ajax/get_cdn_series/ endpoint for normal
    playback at some point (it now returns a generic "session expired"
    error for any request there); reading the page's own embedded config
    instead needs no extra network round-trip and no session state at all.

    A page can embed more than one such call — e.g. a "watch also"/
    recommended-title widget elsewhere on the page has its own player-init
    for a *different* title — so grabbing the first match unconditionally
    can silently return a stranger's stream instead of the one the URL is
    actually for. `expected_id` (the content id embedded in the page's own
    URL, e.g. "2201" in .../2201-univer-novaya-obschaga-2011-latest.html)
    lets every match be checked against it, so a stray widget earlier in
    the HTML is skipped in favour of the real player-init call for this
    title. Without an expected id, the first match wins as before."""
    for m in re.finditer(r'sof\.tv\.initCDN(?:Movies|Series)Events\s*\(\s*(\d+)', html):
        if expected_id is not None and m.group(1) != expected_id:
            continue
        idx = html.find('{', m.end())
        if idx == -1:
            continue
        try:
            obj, _ = json.JSONDecoder().raw_decode(html, idx)
            return obj
        except json.JSONDecodeError:
            continue
    return None


def _parse_season_tabs(html):
    """Season numbers from the season tab bar (#simple-seasons-tabs)."""
    return sorted({
        int(m.group(1)) for m in re.finditer(
            r'<a[^>]+class="b-simple_season__item(?: active)?"[^>]+data-tab_id="(\d+)"', html
        )
    })


def _parse_episode_count(html, season):
    """Highest episode number for `season` in the currently loaded episode
    tab list (#simple-episodes-tabs) — rezka only renders one season's
    episodes per page load, whichever season the URL/tab selects."""
    count = 0
    for m in re.finditer(r'data-season_id="(\d+)"[^>]*data-episode_id="(\d+)"', html):
        if int(m.group(1)) == season:
            count = max(count, int(m.group(2)))
    for m in re.finditer(r'data-episode_id="(\d+)"[^>]*data-season_id="(\d+)"', html):
        if int(m.group(2)) == season:
            count = max(count, int(m.group(1)))
    return count


def _trash_decode(s):
    """Decode rezka 'trash' codec: reverse char substitutions, then base64."""
    s = s.replace("#", "=").replace("@", "/").replace("$", "+")
    pad = len(s) % 4
    if pad:
        s += "=" * (4 - pad)
    try:
        return base64.b64decode(s).decode("utf-8", errors="replace")
    except Exception:
        return s


def _pick_url(parts_str):
    """From 'url1 or url2' pick the direct MP4 variant, else last.

    voidboost.one serves the HLS side of this pair (url with a trailing
    ':hls:manifest.m3u8') as a sliding-window manifest with no
    #EXT-X-ENDLIST, so inputstream.adaptive detects it as a *live*
    stream and keeps force-seeking to the live edge — playback jumps
    forward on its own every few seconds instead of just playing
    (confirmed in kodi.log: "Type: live" followed by repeated PosTime
    jumps seconds apart). The plain MP4 URL alongside it is an ordinary
    progressive file with none of that."""
    parts = [p.strip() for p in parts_str.split(" or ") if p.strip()]
    url = next((p for p in parts if "m3u8" not in p and "hls" not in p), parts[-1])
    return ("https:" + url) if url.startswith("//") else url


def _parse_cdn_url(raw):
    """
    Parse CDN API response `url` field into {quality: stream_url}.
    Handles trash-encoded strings and two plain-text formats:
      - with closing tags:    [720p]url or url2[/720p],[480p]...[/480p]
      - without closing tags: [720p]url or url2,[480p]...
    """
    if not isinstance(raw, str) or not raw:
        return {}

    decoded = raw if "[" in raw else _trash_decode(raw)

    result = {}

    # Format 1: [quality]...[/quality]
    for m in re.finditer(r"\[(\d+p)\](.*?)\[/\1\]", decoded, re.DOTALL):
        result[m.group(1)] = _pick_url(m.group(2))

    # Format 2: [quality]url or url2, (no closing tag, comma-separated)
    if not result:
        for m in re.finditer(r"\[(\d+p)\]([^\[]+)", decoded):
            body = m.group(2).rstrip(", ")
            result[m.group(1)] = _pick_url(body)

    # Fallback: single plain URL
    if not result:
        url = decoded.strip().rstrip(",")
        if url.startswith("//"):
            url = "https:" + url
        if url.startswith("http"):
            result["auto"] = url

    return result


def _translator_page_url(item, translator_name):
    """Base page URL for a given translator name (item['url'] itself if no
    translator name was recorded — the original-track fallback — or if the
    lookup fails for any reason)."""
    if not translator_name:
        return item["url"]
    try:
        links = _parse_translator_links(_fetch(item["url"]))
    except (URLError, HTTPError):
        return item["url"]
    entry = links.get(translator_name)
    if not entry:
        low = translator_name.lower()
        for name, e in links.items():
            if low in name.lower() or name.lower() in low:
                entry = e
                break
    return entry[1] if entry else item["url"]


def _fetch_series_stream_ajax(domain, content_id, translator_id, season, episode):
    """Try rezka's get_cdn_series AJAX endpoint for one specific episode's
    stream — the mechanism a real browser actually uses to switch episodes
    within an already-loaded season page. There is no separate static URL
    per episode (.../1-season/5-episode.html is not a real rezka page — it
    silently serves an unrelated title's page instead of 404ing, see the
    expected_id guard in _extract_cdn_config and 1.4.3/1.4.4's kodi.log).

    This endpoint returned a generic "Время сессии истекло" error for
    every request tried in 1.2.4/1.2.5 despite matching third-party HDrezka
    client headers and cookies, which is why 1.3.0 abandoned it for page
    scraping — but that investigation was inconclusive (based on a
    live capture from a different rezka mirror, never confirmed against
    this domain) before it was dropped. Worth one more real attempt with
    full diagnostics now that the page-scraping fallback has its own
    confirmed problem. Returns {quality: url}, or None on any failure —
    the caller decides what "no AJAX" means; every failure logs the full
    request/response so the *next* occurrence gives real data instead of
    another blind guess."""
    _seed_browser_cookies(domain)
    data = {
        "id": content_id,
        "translator_id": translator_id,
        "season": str(season),
        "episode": str(episode),
        "action": "get_stream",
    }
    req = Request(
        f"{domain}/ajax/get_cdn_series/?t={time.time_ns()}",
        data=urlencode(data).encode(),
        headers={
            "User-Agent": _UA,
            "X-Requested-With": "XMLHttpRequest",
            "Referer": f"{domain}/",
            "Origin": domain,
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept-Encoding": "gzip, deflate",
        },
    )
    try:
        raw_body = _read_response(_open_with_gateway_retry(req, timeout=15))
    except (URLError, HTTPError) as e:
        xbmc.log(f"RezkaLocal: get_cdn_series сетевая ошибка: {e}", xbmc.LOGWARNING)
        return None

    try:
        body = json.loads(raw_body)
    except json.JSONDecodeError:
        xbmc.log(
            f"RezkaLocal: get_cdn_series вернул не JSON. Запрос: {data}, "
            f"ответ (первые 500 символов): {raw_body[:500]!r}",
            xbmc.LOGWARNING,
        )
        return None

    if not body.get("success"):
        host = urlsplit(domain).hostname or ""
        held_cookies = sorted(c.name for c in _cookie_jar if c.domain in (host, f".{host}"))
        xbmc.log(
            f"RezkaLocal: get_cdn_series отказал. Запрос: {data}, "
            f"куки для {host}: {held_cookies}, ответ: {raw_body!r}",
            xbmc.LOGWARNING,
        )
        return None

    return _parse_cdn_url(body.get("url"))


def _fetch_qualities(item, translator_name, season=None, episode=None):
    """
    Fetch stream URLs for a new-format entry by reading the target page's
    own embedded player config (see _extract_cdn_config) — rezka bakes the
    resolved stream URLs directly into each translator/episode page now,
    rather than resolving them via an AJAX call.
    Checks disk cache first; only hits rezka if cache is missing or stale.
    Returns {quality: url} or raises RuntimeError / URLError.
    """
    page_url = item["url"]
    title = item.get("title", "")

    key = _cache_key(title, translator_name, season, episode)
    cache = _load_cache()
    if key in cache:
        cached = cache[key]
        probe = next(iter(cached.values()), None)
        if probe and _probe_url(probe):
            xbmc.log(f"RezkaLocal: кэш жив [{key}]", xbmc.LOGDEBUG)
            return cached
        xbmc.log(f"RezkaLocal: кэш устарел [{key}], обновляем", xbmc.LOGDEBUG)
        del cache[key]
        _save_cache(cache)

    target_url = page_url
    translator_id = None

    if translator_name:
        html = _fetch(page_url)
        links = _parse_translator_links(html)
        entry = links.get(translator_name)
        if not entry:
            low = translator_name.lower()
            for name, e in links.items():
                if low in name.lower() or name.lower() in low:
                    entry = e
                    break

        if entry:
            translator_id, target_url = entry
        else:
            # No href-based (series-style) match. Movies list translators
            # as plain <li> with no href at all — there's no season/
            # episode to combine one with, so rezka switches translator in
            # place via JS/AJAX instead of linking to a separate page. The
            # AJAX endpoint that used to serve that switch is dead (see
            # 1.3.0), so the only translator we can actually still reach
            # is whichever one is already active on this very page.
            movie_entries = _parse_movie_translator_ids(html)
            movie_entry = movie_entries.get(translator_name)
            if not movie_entry:
                low = translator_name.lower()
                for name, e in movie_entries.items():
                    if low in name.lower() or name.lower() in low:
                        movie_entry = e
                        break

            if movie_entry and movie_entry[1]:
                # It's the active one — this page's own config is already
                # for it, no extra fetch needed.
                target_url = page_url
            elif movie_entry:
                active = next((n for n, (t, a) in movie_entries.items() if a), None)
                xbmc.log(
                    f"RezkaLocal: озвучка «{translator_name}» (id {movie_entry[0]}) не активна на "
                    f"{page_url}; активна только «{active}». У фильмов (в отличие от сериалов) нет "
                    f"отдельной ссылки на озвучку, а AJAX-переключение больше не работает.",
                    xbmc.LOGERROR,
                )
                xbmcgui.Dialog().ok(
                    "RezkaLocal — озвучка недоступна",
                    f"«{translator_name}» не выбрана по умолчанию на странице фильма, "
                    f"а отдельной ссылки на неё сайт не даёт (в отличие от сериалов).\n\n"
                    f"Сейчас доступна только: «{active}»",
                )
                raise RuntimeError(f"Озвучка «{translator_name}» недоступна (фильм без AJAX-переключения)")
            elif links or movie_entries:
                found = ", ".join(list(links.keys()) + list(movie_entries.keys()))
                xbmc.log(
                    f"RezkaLocal: озвучка «{translator_name}» не найдена. URL: {page_url}, "
                    f"найдено на странице: {found}",
                    xbmc.LOGERROR,
                )
                xbmcgui.Dialog().ok(
                    "RezkaLocal — озвучка не найдена",
                    f"Искали: «{translator_name}»\n\nНайдено на странице:\n{found}",
                )
                raise RuntimeError(f"Озвучка «{translator_name}» не найдена. На странице: {found}")
            else:
                # Nothing parsed at all — either the page is still an
                # unsolved Anubis challenge (a failed _solve_anubis
                # silently leaves the challenge HTML in place instead of
                # raising) or the site changed the markup yet again. Log
                # enough of the raw HTML to tell those apart from the next
                # kodi.log, instead of relying on the on-screen dialog
                # (easy to dismiss without reading, and never lands in the
                # log file).
                xbmc.log(
                    f"RezkaLocal: переводы не найдены вообще. URL: {page_url}, "
                    f"anubis_challenge в html: {'anubis_challenge' in html}, "
                    f"длина html: {len(html)}, начало: {html[:800]!r}",
                    xbmc.LOGERROR,
                )
                xbmcgui.Dialog().ok(
                    "RezkaLocal — ошибка",
                    f"Озвучки не найдены вообще.\n\nURL: {page_url}\n\nHTML начало:\n{html[:300]}",
                )
                raise RuntimeError(f"Озвучка «{translator_name}» не найдена на странице")

    id_m = re.search(r'/(\d+)-[^/]+\.html', item.get("url", ""))
    expected_id = id_m.group(1) if id_m else None

    if season is not None:
        # There is no static per-episode URL on rezka — .../1-season/
        # 5-episode.html is not a real page: it silently serves whatever
        # unrelated title happens to sit at that path instead of 404ing
        # (confirmed in kodi.log: it returned a different movie's page
        # entirely). A real browser switches episodes within a loaded
        # season page via an AJAX call instead. Try that first; the
        # guessed URL below only ever runs as a fallback now, and even
        # then the expected_id check above stops it from silently
        # serving whatever's on that wrong page.
        resolved_translator_id = translator_id
        if resolved_translator_id is None:
            # No translator was explicitly resolved (original/only track).
            # Read the id straight off target_url's own default
            # player-init call instead of guessing at one.
            probe_html = html if translator_name else _fetch(target_url)
            m = re.search(r'sof\.tv\.initCDNSeriesEvents\s*\(\s*\d+\s*,\s*(\d+)', probe_html)
            resolved_translator_id = m.group(1) if m else None

        ajax_qualities = None
        if expected_id and resolved_translator_id:
            ajax_qualities = _fetch_series_stream_ajax(
                _domain_of(target_url), expected_id, resolved_translator_id, season, episode
            )
        if ajax_qualities:
            cache = _load_cache()
            cache[key] = ajax_qualities
            _save_cache(cache)
            return ajax_qualities

        target_url = re.sub(r'\.html$', '', target_url) + f"/{season}-season/{episode}-episode.html"

    html = _fetch(target_url)
    config = _extract_cdn_config(html, expected_id=expected_id)

    if not config or not config.get("streams"):
        # Log everything needed to tell apart "wrong URL, page has no
        # player-init call for this id at all" from "right page, id
        # matched but streams missing (premium-only quality)" from "still
        # stuck on an unsolved Anubis challenge" from the next kodi.log,
        # instead of guessing again.
        found_ids = re.findall(r'sof\.tv\.initCDN(?:Movies|Series)Events\s*\(\s*(\d+)', html)
        xbmc.log(
            f"RezkaLocal: не удалось извлечь конфиг плеера. URL: {target_url}, "
            f"ожидаемый id: {expected_id}, найденные id на странице: {found_ids}, "
            f"anubis_challenge в html: {'anubis_challenge' in html}, "
            f"длина html: {len(html)}, начало: {html[:500]!r}",
            xbmc.LOGERROR,
        )
        raise RuntimeError(
            "Не удалось получить ссылки на поток со страницы "
            "(возможно, этот перевод доступен только для Premium)"
        )

    qualities = _parse_cdn_url(config["streams"])
    if not qualities:
        raise RuntimeError(f"Не удалось разобрать ссылки на поток. streams={config['streams'][:200]!r}")

    cache = _load_cache()
    cache[key] = qualities
    _save_cache(cache)
    return qualities


# ── KinoGo / cinemar.cc helpers ──────────────────────────────────────────────

KINOGO_COOKIE_PATH = os.path.join(ADDON_PATH, "kinogo_cookies.lwp")
KINOGO_CACHE_PATH = os.path.join(ADDON_PATH, "kinogo_cache.json")
KINOGO_CACHE_TTL = 1800  # 30 minutes

_kinogo_jar = http.cookiejar.LWPCookieJar(KINOGO_COOKIE_PATH)
try:
    _kinogo_jar.load(ignore_discard=True, ignore_expires=True)
except Exception:
    pass
_kinogo_opener = build_opener(HTTPCookieProcessor(_kinogo_jar))

_KINOGO_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    "Accept-Encoding": "gzip, deflate",
    "DNT": "1",
    "Upgrade-Insecure-Requests": "1",
}


def _fetch_kinogo(url):
    """Fetch a kinogo page using saved CF cookies when available."""
    req = Request(url, headers=_KINOGO_HEADERS)
    try:
        html = _read_response(_kinogo_opener.open(req, timeout=20))
        try:
            _kinogo_jar.save(ignore_discard=True, ignore_expires=True)
        except Exception:
            pass
        return html
    except (HTTPError, URLError) as e:
        raise RuntimeError(f"Не удалось загрузить kinogo ({e})")


def _extract_cinemar_url(html):
    """Extract cinemar.cc embed URL from kinogo page HTML."""
    for pat in (
        r'<iframe[^>]+src=["\']([^"\']*cinemar\.cc/embed/[^"\']+)["\']',
        r'data-src=["\']([^"\']*cinemar\.cc/embed/[^"\']+)["\']',
        r'"src"\s*:\s*"([^"]*cinemar\.cc/embed/[^"]+)"',
        r"'src'\s*:\s*'([^']*cinemar\.cc/embed/[^']+)'",
    ):
        m = re.search(pat, html, re.IGNORECASE)
        if m:
            u = m.group(1)
            return u if u.startswith("http") else "https:" + u
    return None


def _fetch_cinemar_embed(embed_url, page_referer=None):
    """
    Fetch cinemar.cc embed page.
    page_referer must be the kinogo page URL that contains the iframe —
    cinemar.cc checks it and returns an empty/blocked page without it.
    """
    m_domain = re.match(r'(https?://[^/]+)', page_referer or "")
    origin = m_domain.group(1) if m_domain else "https://kinogo.online"
    referer = page_referer or "https://kinogo.online/"
    req = Request(embed_url, headers={
        "User-Agent": _UA,
        "Referer": referer,
        "Origin": origin,
        "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate",
    })
    return _read_response(_opener.open(req, timeout=15))


def _extract_cinemar_encoded(html):
    """Extract encoded playlist string (#236z, #237T, or any #2NN...) from cinemar embed HTML."""
    _ENC = r'#2\d{2}[^"\'<>\s\\]{10,}'
    for pat in (
        # JSON key with quotes: "file":"#2..."  (Cinemar({..."file":"#237T..."...}))
        rf'"file"\s*:\s*"({_ENC})"',
        # JS object literal without quotes on key: file: "#2..."
        rf'file\s*:\s*["\']?({_ENC})',
        # JS variable assignment
        rf'(?:var|let|const)\s+\w+\s*=\s*["\']?({_ENC})',
        # data attribute
        rf'data-(?:file|src|playlist)\s*=\s*["\']?({_ENC})',
        # catch-all: first occurrence of any #2NN<letter>... in the page
        rf'({_ENC})',
    ):
        m = re.search(pat, html)
        if m:
            return m.group(1)
    xbmc.log(f"RezkaLocal: encoded playlist не найден. Начало embed HTML: {html[:1200]}", xbmc.LOGWARNING)
    return None


def _decode_cinemar_236z(encoded):
    """Decode legacy #236z (Playerjs) playlist."""
    if encoded.startswith("#236z"):
        encoded = encoded[5:]
    parts = []
    for seg in encoded.split("$"):
        if not seg:
            continue
        idx = ord(seg[-1]) - 48
        body = seg[:-1]
        if 0 < idx <= len(body):
            body = body[idx:] + body[:idx]
        parts.append(body)
    joined = "".join(parts)
    padding = (4 - len(joined) % 4) % 4
    raw = base64.b64decode(joined + "=" * padding)
    latin = raw.decode("latin-1")
    pct = "".join(f"%{ord(c):02X}" if ord(c) > 127 else c for c in latin)
    return json.loads(unquote(pct))


def _decode_cinemar_237T(encoded):
    """
    Decode Cinemar player #237T playlist.
    Format: "#2" + 2-digit delimiter code + data split by that delimiter char.
    Each segment longer than 32 chars is unshuffled:
      result = seg[2t : len-t-1] + seg[0:t]   where t = int(last_char)
    Then base64-decode → latin-1 → percent-encode high bytes → unquote → JSON.
    """
    e = encoded[2:]          # strip "#2" → "37TA0M2V0..."
    try:
        dm = int(e[:2])      # "37" → 37
    except ValueError:
        dm = 36              # fallback
    delimiter = chr(dm)      # chr(37) = '%'
    body = e[2:]             # "TA0M2V0..."
    _ml = 32

    parts = []
    for seg in body.split(delimiter):
        if not seg:
            continue
        if len(seg) > _ml:
            try:
                t = int(seg[-1])
            except ValueError:
                parts.append(seg)
                continue
            # JS: seg.substr(2*t, seg.length-3*t-1) + seg.substr(0, t)
            # Python equiv (substr second arg is LENGTH):
            unshuffled = seg[2 * t: len(seg) - t - 1] + seg[:t]
            parts.append(unshuffled)
        else:
            parts.append(seg)

    joined = "".join(parts)
    rem = len(joined) % 4
    if rem == 1:
        raise RuntimeError(
            f"#236z decode: joined base64 length {len(joined)} % 4 == 1 — wrong decoder or corrupted data"
        )
    padding = (4 - rem) % 4
    raw = base64.b64decode(joined + "=" * padding)
    latin = raw.decode("latin-1")
    pct = "".join(f"%{ord(c):02X}" if ord(c) > 127 else c for c in latin)
    return json.loads(unquote(pct))


def _decode_cinemar_playlist(encoded):
    """Dispatch to the right decoder based on the encoded string prefix."""
    xbmc.log(f"RezkaLocal: cinemar encoded prefix={encoded[:12]!r}", xbmc.LOGDEBUG)
    if encoded.startswith("#236z"):
        return _decode_cinemar_236z(encoded)
    if encoded.startswith("#2"):
        # Any #2NNX format (e.g. #237T, #236T, #236A) uses the Cinemar algorithm.
        # The 2-digit code is the ASCII code of the delimiter char.
        return _decode_cinemar_237T(encoded)
    return _decode_cinemar_236z(encoded)


def _node_file(node):
    """Return the raw file/dlink string from a playlist leaf node, or ''."""
    return node.get("file") or node.get("dlink") or ""


def _strip_html(text):
    return re.sub(r'<[^>]+>', '', text or '').strip()


def _kinogo_get_translators(playlist):
    """Return unique translator names (leaf nodes with 'file' or 'dlink') from any playlist structure."""
    names = []
    seen = set()

    def walk(node):
        if _node_file(node) and "title" in node:
            n = _strip_html(node["title"])
            if n not in seen:
                seen.add(n)
                names.append(n)
        for child in node.get("folder", []):
            walk(child)

    for item in playlist:
        walk(item)
    return names


def _playlist_is_series(playlist):
    """True if the playlist has at least two levels of folders (season/episode/voice)."""
    if not playlist:
        return False
    sub = playlist[0].get("folder", [])
    return bool(sub) and "folder" in sub[0]


def _pick_hls(file_str):
    """Pick best HLS URL from a 'url1 or url2' file string."""
    parts = [p.strip() for p in file_str.split(" or ") if p.strip()]
    if not parts:
        return ""
    url = next((p for p in reversed(parts) if "m3u8" in p or "hls" in p), parts[-1])
    return ("https:" + url) if url.startswith("//") else url


def _parse_quality_urls(file_str):
    """Split Playerjs '[720p]url or [1080p]url' or bare 'url1 or url2' into [(label, url), ...]."""
    if not file_str:
        return []
    raw = [p.strip() for p in file_str.split(" or ") if p.strip()]
    result = []
    for part in raw:
        # Playerjs bracket prefix: [720p]//cdn/.../hls.m3u8
        m_pfx = re.match(r'^\[([^\]]+)\]', part)
        if m_pfx:
            label = m_pfx.group(1)
            part = part[m_pfx.end():]
        else:
            label = None
        url = ("https:" + part) if part.startswith("//") else part
        if not label:
            m = re.search(r'[/_](\d{3,4})[pP]?(?:[/_.]|$)', url)
            if m:
                label = f"{m.group(1)}p"
            elif len(raw) == 1:
                label = "Авто"
            else:
                label = f"Поток {len(result) + 1}"
        result.append((label, url))
    if len(result) > 1:
        try:
            result.sort(key=lambda x: int(re.search(r'\d+', x[0]).group()), reverse=True)
        except (AttributeError, ValueError):
            pass
    return result


def _cdn_url_is_stale(url):
    """Return True if the CDN URL's hour token (:YYYYMMDDhh/) doesn't match the current hour."""
    m = re.search(r':(\d{10})/', url)
    if not m:
        return False
    return m.group(1) != time.strftime("%Y%m%d%H")


def _fetch_hls_qualities(url, referer):
    """Fetch HLS master manifest and return [(label, variant_url), ...] sorted best→worst.

    Each variant_url points to a single-bitrate media playlist — no ABR switching.
    Returns empty list if the URL is not a master manifest or on network error.
    """
    from urllib.parse import urljoin
    try:
        req = Request(url, headers={
            "User-Agent": _UA,
            "Referer": referer,
            "Accept-Encoding": "gzip, deflate",
        })
        resp = _opener.open(req, timeout=35)
        # The CDN 302-redirects to a specific edge host (e.g. stream.voidboost.one
        # -> flerovium.stream.voidboost.one); relative variant URIs in the manifest
        # must resolve against that final host, not the pre-redirect one.
        base_url = resp.geturl()
        text = _read_response(resp)
    except Exception as e:
        xbmc.log(f"RezkaLocal: HLS manifest fetch failed [{url}]: {e}", xbmc.LOGWARNING)
        return []

    variants = []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith("#EXT-X-STREAM-INF"):
            res_m = re.search(r'RESOLUTION=(\d+)x(\d+)', line)
            bw_m = re.search(r'BANDWIDTH=(\d+)', line)
            # Next non-empty, non-comment line is the variant URI
            j = i + 1
            while j < len(lines) and (not lines[j].strip() or lines[j].strip().startswith("#")):
                j += 1
            if j < len(lines):
                variant_uri = lines[j].strip()
                if variant_uri:
                    variant_url = urljoin(base_url, variant_uri)
                    if res_m:
                        label = f"{res_m.group(2)}p"
                    elif bw_m:
                        label = f"{int(bw_m.group(1)) // 1000}k"
                    else:
                        label = f"Поток {len(variants) + 1}"
                    variants.append((label, variant_url))
            i = j + 1
        else:
            i += 1

    if not variants:
        return []

    # Sort descending by resolution height (or bandwidth number)
    def _sort_key(item):
        m = re.search(r'(\d+)', item[0])
        return int(m.group(1)) if m else 0

    variants.sort(key=_sort_key, reverse=True)
    return variants


def _load_kinogo_cache():
    try:
        with open(KINOGO_CACHE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_kinogo_cache(cache):
    try:
        with open(KINOGO_CACHE_PATH, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception as e:
        xbmc.log(f"RezkaLocal: kinogo cache save failed: {e}", xbmc.LOGWARNING)



def _get_kinogo_playlist(page_url, force=False):
    """
    Return decoded cinemar.cc playlist for a kinogo URL, cached for KINOGO_CACHE_TTL seconds.
    Raises RuntimeError on network / parse failure.
    """
    cache = _load_kinogo_cache()
    entry = cache.get(page_url, {})
    now = int(time.time())

    if not force and entry and now - entry.get("fetched_at", 0) < KINOGO_CACHE_TTL:
        playlist = entry.get("playlist")
        if playlist:
            xbmc.log("RezkaLocal: kinogo cache hit", xbmc.LOGDEBUG)
            return playlist

    html = _fetch_kinogo(page_url)

    embed_url = _extract_cinemar_url(html)
    if not embed_url:
        raise RuntimeError(
            "cinemar.cc embed не найден на странице kinogo. "
            "Возможно, Cloudflare блокирует запрос — попробуй с домашнего IP."
        )

    embed_html = _fetch_cinemar_embed(embed_url, page_referer=page_url)
    encoded = _extract_cinemar_encoded(embed_html)
    if not encoded:
        raise RuntimeError("Зашифрованный плейлист не найден на странице cinemar.cc")

    xbmc.log(f"RezkaLocal: cinemar encoded prefix: {encoded[:10]}", xbmc.LOGDEBUG)
    playlist = _decode_cinemar_playlist(encoded)
    xbmc.log(f"RezkaLocal: cinemar playlist sample: {json.dumps(playlist[:1], ensure_ascii=False)[:400]}", xbmc.LOGDEBUG)

    cache[page_url] = {"playlist": playlist, "fetched_at": now}
    _save_kinogo_cache(cache)
    return playlist


def _show_kinogo_translators(item):
    title = item["title"]
    try:
        playlist = _get_kinogo_playlist(item["url"])
    except RuntimeError as e:
        _notify_error(str(e))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    translators = _kinogo_get_translators(playlist)
    if not translators:
        _notify_error("Переводы не найдены в плейлисте cinemar.cc")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    is_series = "seasons" in item or _playlist_is_series(playlist)
    next_action = "list_seasons" if is_series else "list_qualities"

    for name in translators:
        li = xbmcgui.ListItem(label=f"Озвучка: {name}")
        xbmcplugin.addDirectoryItem(HANDLE, _url(action=next_action, id=item["id"], translator=name), li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def _show_kinogo_seasons(item, translator):
    title = item["title"]
    try:
        playlist = _get_kinogo_playlist(item["url"])
    except RuntimeError as e:
        _notify_error(str(e))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for s_idx, season_item in enumerate(playlist, 1):
        label = _strip_html(season_item.get("title", f"Сезон {s_idx}"))
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": label, "season": s_idx})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="list_episodes", id=item["id"], translator=translator, season=str(s_idx)),
            li,
            True,
        )
    xbmcplugin.endOfDirectory(HANDLE)


def _show_kinogo_episodes(item, translator, season):
    title = item["title"]
    try:
        playlist = _get_kinogo_playlist(item["url"])
    except RuntimeError as e:
        _notify_error(str(e))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    s_idx = int(season)
    if s_idx < 1 or s_idx > len(playlist):
        _notify_error(f"Сезон {season} не найден (доступно: {len(playlist)})")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    season_folder = playlist[s_idx - 1].get("folder", [])

    for ep_idx, ep_item in enumerate(season_folder, 1):
        ep_label = _strip_html(ep_item.get("title", f"Серия {ep_idx}"))
        li = xbmcgui.ListItem(label=ep_label)
        li.setInfo("video", {"title": f"{title} {ep_label}", "episode": ep_idx, "season": s_idx})

        hls_file = ""
        for voice in ep_item.get("folder", []):
            if _strip_html(voice.get("title", "")) == translator:
                hls_file = _node_file(voice)
                break

        if hls_file:
            # Always route through quality folder so the user picks an explicit static bitrate
            xbmcplugin.addDirectoryItem(
                HANDLE,
                _url(action="list_kinogo_ep_qualities", id=item["id"],
                     translator=translator, season=str(s_idx), ep_idx=str(ep_idx)),
                li, True,
            )
        else:
            continue

    xbmcplugin.endOfDirectory(HANDLE)


def _show_kinogo_ep_qualities(item, translator, season, ep_idx):
    title = item["title"]
    s_idx = int(season)
    ep_n = int(ep_idx)

    def _extract_ep(pl):
        sf = pl[s_idx - 1].get("folder", []) if s_idx <= len(pl) else []
        if ep_n < 1 or ep_n > len(sf):
            return None, ""
        ep = sf[ep_n - 1]
        label = _strip_html(ep.get("title", f"Серия {ep_n}"))
        hls = ""
        for voice in ep.get("folder", []):
            if _strip_html(voice.get("title", "")) == translator:
                hls = _node_file(voice)
                break
        return label, hls

    try:
        playlist = _get_kinogo_playlist(item["url"])
    except RuntimeError as e:
        _notify_error(str(e))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    ep_label, hls_file = _extract_ep(playlist)
    if ep_label is None:
        _notify_error(f"Серия {ep_n} не найдена")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    playerjs_qualities = _parse_quality_urls(hls_file)
    best_url = playerjs_qualities[0][1] if playerjs_qualities else ""

    # Refresh only when the hour token in the CDN URL has expired;
    # if kinogo is unreachable, fall back silently to the cached (stale) URLs
    if best_url and _cdn_url_is_stale(best_url):
        try:
            fresh = _get_kinogo_playlist(item["url"], force=True)
            fresh_label, fresh_hls = _extract_ep(fresh)
            if fresh_label is not None:
                ep_label, hls_file = fresh_label, fresh_hls
                playerjs_qualities = _parse_quality_urls(hls_file)
                best_url = playerjs_qualities[0][1] if playerjs_qualities else ""
        except RuntimeError:
            xbmc.log("RezkaLocal: stale URL refresh failed, using cached data", xbmc.LOGWARNING)

    qualities = []
    if best_url and ".m3u8" in best_url:
        try:
            qualities = _fetch_hls_qualities(best_url, "https://kinogo.online/")
        except Exception:
            pass

    if not qualities:
        qualities = playerjs_qualities

    if not qualities:
        _notify_error(f"URL не найден для озвучки: {translator}")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for q_label, q_url in qualities:
        li = xbmcgui.ListItem(label=f"{ep_label} [{q_label}]")
        li.setInfo("video", {"title": f"{title} {ep_label} [{q_label}]", "episode": ep_n, "season": s_idx})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, _url(action="play", video_url=q_url), li, False)

    xbmcplugin.endOfDirectory(HANDLE)


def _show_kinogo_movie_qualities(item, translator):
    title = item["title"]

    def _extract_movie(pl):
        hls = ""
        for node in pl:
            if _strip_html(node.get("title", "")) == translator and _node_file(node):
                hls = _node_file(node)
                break
            for sub in node.get("folder", []):
                if _strip_html(sub.get("title", "")) == translator and _node_file(sub):
                    hls = _node_file(sub)
                    break
            if hls:
                break
        return hls

    try:
        playlist = _get_kinogo_playlist(item["url"])
    except RuntimeError as e:
        _notify_error(str(e))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    hls_file = _extract_movie(playlist)
    playerjs_qualities = _parse_quality_urls(hls_file)
    best_url = playerjs_qualities[0][1] if playerjs_qualities else ""

    # Refresh only when the hour token in the CDN URL has expired;
    # if kinogo is unreachable, fall back silently to the cached (stale) URLs
    if best_url and _cdn_url_is_stale(best_url):
        try:
            fresh = _get_kinogo_playlist(item["url"], force=True)
            fresh_hls = _extract_movie(fresh)
            if fresh_hls:
                hls_file = fresh_hls
                playerjs_qualities = _parse_quality_urls(hls_file)
                best_url = playerjs_qualities[0][1] if playerjs_qualities else ""
        except RuntimeError:
            xbmc.log("RezkaLocal: stale URL refresh failed, using cached data", xbmc.LOGWARNING)

    qualities = []
    if best_url and ".m3u8" in best_url:
        try:
            qualities = _fetch_hls_qualities(best_url, "https://kinogo.online/")
        except Exception:
            pass

    if not qualities:
        qualities = playerjs_qualities

    if not qualities:
        _notify_error(f"URL не найден для перевода: {translator}")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for q_label, q_url in qualities:
        li = xbmcgui.ListItem(label=f"Смотреть [{translator}] [{q_label}]")
        li.setInfo("video", {"title": f"{title} [{translator}] [{q_label}]"})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, _url(action="play", video_url=q_url), li, False)

    xbmcplugin.endOfDirectory(HANDLE)


# ── Kodi helpers ──────────────────────────────────────────────────────────────

def _url(**kwargs):
    return f"{BASE_URL}?{urlencode(kwargs)}"


def _notify_error(msg):
    xbmc.log(f"RezkaLocal ERROR: {msg}", xbmc.LOGERROR)
    xbmcgui.Dialog().notification("RezkaLocal", msg, xbmcgui.NOTIFICATION_ERROR, 6000)


def _load_cache():
    if not os.path.exists(CACHE_PATH):
        return {}
    try:
        with open(CACHE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_cache(cache):
    try:
        with open(CACHE_PATH, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception as e:
        xbmc.log(f"RezkaLocal: ошибка сохранения кэша: {e}", xbmc.LOGWARNING)


def _cache_key(title, translator, season, episode):
    return "|".join([title, translator, str(season) if season is not None else "", str(episode) if episode is not None else ""])


def _probe_url(url):
    """Check if a cached CDN URL is still alive via a 1-byte range request."""
    try:
        req = Request(url, headers={"User-Agent": _UA, "Range": "bytes=0-0"})
        with _opener.open(req, timeout=5) as r:
            return r.getcode() in (200, 206)
    except Exception:
        return False


def _db_connect():
    """Open the packaged SQLite database read-only. Using the URI mode=ro
    form (rather than a plain path) stops SQLite from trying to create a
    -journal/-wal file next to it, which the addon directory may not be
    writable for anyway."""
    return sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)


def _row_to_item(conn, row):
    """Reassemble one `items` row (+ its translators/seasons/hls_episodes)
    into the same dict shape the old JSON entries had — translators as
    either a plain list of names or a {name: {quality: url}} dict, seasons
    and hls_episodes as nested dicts keyed by string numbers — so every
    other function in this file keeps working unchanged."""
    item_id, title, type_, url, source = row
    item = {"id": item_id, "title": title, "type": type_, "url": url}
    if source:
        item["source"] = source

    t_rows = conn.execute(
        "SELECT id, name FROM translators WHERE item_id = ? ORDER BY position", (item_id,)
    ).fetchall()

    url_rows = conn.execute(
        """SELECT translator_id, quality, url FROM translator_urls
           WHERE translator_id IN (SELECT id FROM translators WHERE item_id = ?)""",
        (item_id,),
    ).fetchall()
    urls_by_translator = {}
    for t_id, quality, u in url_rows:
        urls_by_translator.setdefault(t_id, {})[quality] = u

    if urls_by_translator:
        item["translators"] = {name: urls_by_translator.get(t_id, {}) for t_id, name in t_rows}
    else:
        item["translators"] = [name for _, name in t_rows]

    season_rows = conn.execute(
        "SELECT season, episode_count FROM seasons WHERE item_id = ?", (item_id,)
    ).fetchall()
    if season_rows:
        item["seasons"] = {str(s): c for s, c in season_rows}

    hls_rows = conn.execute(
        "SELECT season, episode, url FROM hls_episodes WHERE item_id = ?", (item_id,)
    ).fetchall()
    if hls_rows:
        hls = {}
        for s, e, u in hls_rows:
            hls.setdefault(str(s), {})[str(e)] = u
        item["hls_episodes"] = hls

    return item


def _find_item_by_id(item_id):
    """Look up an item by its items.id primary key — not by title. Titles
    aren't unique: 5000+ appear more than once within the same category
    and 3000+ across different categories (e.g. a film and an anime with
    the same name), so routing on title alone could open a title-matching
    but otherwise unrelated item from a different category than the one
    the user actually picked it from."""
    if not os.path.exists(DB_PATH):
        xbmc.log(f"RezkaLocal: база не найдена: {DB_PATH}", xbmc.LOGERROR)
        return None
    try:
        conn = _db_connect()
        try:
            row = conn.execute(
                "SELECT id, title, type, url, source FROM items WHERE id = ?",
                (item_id,),
            ).fetchone()
            return _row_to_item(conn, row) if row else None
        finally:
            conn.close()
    except sqlite3.Error as e:
        xbmc.log(f"RezkaLocal: ошибка SQLite: {e}", xbmc.LOGERROR)
        return None


def _render_qualities(title, qualities, referer=None):
    """Render quality → play items. qualities = {quality_str: stream_url}.
    referer, when given, is the source page's own URL (e.g. from a
    hdrezka-home.tv entry in rezka_database.json) so playback uses the same
    domain the stream was fetched from instead of always defaulting to rezka.ag."""
    ordered = sorted(
        qualities.items(),
        key=lambda kv: _QUALITY_ORDER.index(kv[0]) if kv[0] in _QUALITY_ORDER else 99,
    )
    for quality, stream_url in ordered:
        li = xbmcgui.ListItem(label=f"Качество: {quality}")
        li.setInfo("video", {"title": f"{title} [{quality}]"})
        li.setProperty("IsPlayable", "true")
        extra = {"referer": referer} if referer else {}
        xbmcplugin.addDirectoryItem(HANDLE, _url(action="play", video_url=stream_url, **extra), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Navigation handlers ───────────────────────────────────────────────────────

def show_categories():
    for cat in ("фильмы", "сериалы", "мультфильмы", "аниме"):
        li = xbmcgui.ListItem(label=cat.capitalize())
        li.setInfo("video", {"title": cat.capitalize()})
        xbmcplugin.addDirectoryItem(HANDLE, _url(action="list_items", category=cat), li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_items(category, query=""):
    # Search entry at the top
    search_li = xbmcgui.ListItem(label="[Поиск...]")
    search_li.setInfo("video", {"title": "Поиск"})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="search", category=category), search_li, True)

    needle = query.lower().strip()
    if not needle:
        # Don't dump the whole category (tens of thousands of titles) into
        # one Kodi listing just for opening it — building/rendering that
        # many list items is what makes it crawl on weak hardware (TV
        # boxes). Wait for an actual search query instead.
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if not os.path.exists(DB_PATH):
        xbmc.log(f"RezkaLocal: база не найдена: {DB_PATH}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    try:
        conn = _db_connect()
        try:
            # Scoped by the indexed `type` column instead of loading and
            # parsing the whole database — the substring match itself stays
            # in Python (title.lower()) since SQLite's own LOWER()/NOCASE
            # only case-folds ASCII, not Cyrillic.
            rows = conn.execute(
                """SELECT id, title, EXISTS(SELECT 1 FROM seasons WHERE seasons.item_id = items.id)
                   FROM items WHERE type = ? ORDER BY title""",
                (category,),
            ).fetchall()
        finally:
            conn.close()
    except sqlite3.Error as e:
        xbmc.log(f"RezkaLocal: ошибка SQLite: {e}", xbmc.LOGERROR)
        rows = []

    for item_id, title, is_series in rows:
        if needle not in title.lower():
            continue
        li = xbmcgui.ListItem(label=title)
        li.setInfo("video", {"title": title, "mediatype": "tvshow" if is_series else "movie"})
        xbmcplugin.addDirectoryItem(HANDLE, _url(action="list_translators", id=item_id), li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_search(category):
    query = xbmcgui.Dialog().input("Поиск", type=xbmcgui.INPUT_ALPHANUM)
    if not query:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    show_items(category, query=query)


def show_translators(item_id):
    item = _find_item_by_id(item_id)
    if not item:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if item.get("source") == "kinogo":
        _show_kinogo_translators(item)
        return

    translators = item.get("translators", {})
    # New format: list of names. Old format: dict {name: {quality: url}}.
    names = translators if isinstance(translators, list) else list(translators.keys())
    is_series = "seasons" in item

    if not is_series:
        # Some scraped batches (the whole current "аниме" category) never
        # recorded episode counts, so a title can be a real multi-episode
        # series with no "seasons" key at all — treating that as a movie
        # would resolve only whatever episode the base URL defaults to.
        # Check the live page instead of trusting the (incomplete) data.
        try:
            is_series = 'id="simple-episodes-tabs"' in _fetch(item["url"])
        except (URLError, HTTPError):
            pass

    next_action = "list_seasons" if is_series else "list_qualities"

    if not names:
        # No translators recorded — rezka renders no selectable list when
        # there's just one (usually original-language) track, so skip
        # straight to seasons/qualities instead of showing an empty menu.
        # _fetch_qualities resolves the actual track id from the page.
        if is_series:
            show_seasons(item_id, "")
        else:
            show_qualities(item_id, "")
        return

    for name in names:
        li = xbmcgui.ListItem(label=f"Озвучка: {name}")
        xbmcplugin.addDirectoryItem(HANDLE, _url(action=next_action, id=item_id, translator=name), li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_qualities(item_id, translator):
    """
    Movies/cartoons quality menu.
    Old format: static URLs from database.
    New format: fetch from rezka CDN API or kinogo cinemar playlist.
    """
    item = _find_item_by_id(item_id)
    if not item:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    title = item["title"]

    if item.get("source") == "kinogo":
        _show_kinogo_movie_qualities(item, translator)
        return

    translators = item.get("translators", {})

    if isinstance(translators, dict):
        # Old format — use stored static stream URLs
        qualities = translators.get(translator, {})
        _render_qualities(title, qualities, referer=item.get("url"))
    else:
        # New format — fetch live from rezka
        try:
            qualities = _fetch_qualities(item, translator)
        except (URLError, HTTPError) as e:
            _notify_error(f"Сетевая ошибка: {e}")
            xbmcplugin.endOfDirectory(HANDLE)
            return
        except RuntimeError as e:
            _notify_error(str(e))
            xbmcplugin.endOfDirectory(HANDLE)
            return
        _render_qualities(title, qualities, referer=item.get("url"))


def show_seasons(item_id, translator):
    item = _find_item_by_id(item_id)
    if not item:
        xbmcgui.Dialog().ok("RezkaLocal", "Сериал не найден в базе")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if item.get("source") == "kinogo":
        _show_kinogo_seasons(item, translator)
        return

    # Season numbers scraped into the database are unreliable — missing
    # entirely for some titles (all of "аниме"), incomplete for others
    # (e.g. only season 2 recorded for a show that has a season 1 too).
    # Always read the live page's season tab bar instead; fall back to
    # whatever's stored only if the site can't be reached at all.
    try:
        html = _fetch(_translator_page_url(item, translator))
        seasons = [str(s) for s in _parse_season_tabs(html)]
    except (URLError, HTTPError):
        seasons = []
    if not seasons:
        seasons = sorted(item.get("seasons", {}).keys(), key=int) or ["1"]

    for s in seasons:
        li = xbmcgui.ListItem(label=f"Сезон {s}")
        li.setInfo("video", {"title": f"Сезон {s}", "season": int(s)})
        xbmcplugin.addDirectoryItem(
            HANDLE, _url(action="list_episodes", id=item_id, translator=translator, season=s), li, True
        )
    xbmcplugin.endOfDirectory(HANDLE)


def show_episodes(item_id, translator, season):
    item = _find_item_by_id(item_id)
    if not item:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    title = item["title"]

    if item.get("source") == "kinogo":
        _show_kinogo_episodes(item, translator, season)
        return

    hls_season = item.get("hls_episodes", {}).get(str(season), {})

    # Same story as show_seasons: stored episode counts are unreliable, so
    # read the live season page's episode tab list instead, falling back
    # to the stored count only if the site can't be reached.
    try:
        base = re.sub(r'\.html$', '', _translator_page_url(item, translator))
        html = _fetch(f"{base}/{season}-season.html")
        ep_count = _parse_episode_count(html, int(season))
    except (URLError, HTTPError):
        ep_count = 0
    if not ep_count:
        ep_count = int(item.get("seasons", {}).get(str(season), 0))

    for ep in range(1, ep_count + 1):
        label = f"Серия {ep}"
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": f"{title} С{season}Е{ep:02d}", "episode": ep, "season": int(season)})
        hls_url = hls_season.get(str(ep))
        if hls_url:
            li.setProperty("IsPlayable", "true")
            extra = {"referer": item["url"]} if item.get("url") else {}
            xbmcplugin.addDirectoryItem(HANDLE, _url(action="play", video_url=hls_url, **extra), li, False)
        else:
            xbmcplugin.addDirectoryItem(
                HANDLE,
                _url(action="list_episode_qualities", id=item_id, translator=translator,
                     season=season, episode=ep),
                li,
                True,
            )
    xbmcplugin.endOfDirectory(HANDLE)


def show_episode_qualities(item_id, translator, season, episode):
    """Fetch stream URLs for one episode and show quality menu."""
    item = _find_item_by_id(item_id)
    if not item:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    title = item["title"]

    try:
        qualities = _fetch_qualities(item, translator, season=int(season), episode=int(episode))
    except (URLError, HTTPError) as e:
        _notify_error(f"Сетевая ошибка: {e}")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    except RuntimeError as e:
        _notify_error(str(e))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    _render_qualities(f"{title} С{season}Е{int(episode):02d}", qualities, referer=item.get("url"))


def play_video(video_url, referer=None):
    if not referer:
        if any(d in video_url for d in ("cinemap.cc", "cinemar.cc", "kinogo")):
            referer = "https://kinogo.online/"
        else:
            referer = f"{_DEFAULT_REZKA_DOMAIN}/"

    if ".m3u8" in video_url:
        try:
            xbmcaddon.Addon("inputstream.adaptive")
            li = xbmcgui.ListItem(path=video_url)
            li.setMimeType("application/x-mpegURL")
            li.setContentLookup(False)
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
            hdr = f"Referer={referer}&User-Agent={_UA}"
            li.setProperty("inputstream.adaptive.stream_headers", hdr)
            li.setProperty("inputstream.adaptive.manifest_headers", hdr)
            xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)
            return
        except Exception:
            pass

    headers = urlencode({"User-Agent": _UA, "Referer": referer})
    li = xbmcgui.ListItem(path=f"{video_url}|{headers}")
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)


def show_kinogo_ep_qualities(item_id, translator, season, ep_idx):
    item = _find_item_by_id(item_id)
    if not item:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    _show_kinogo_ep_qualities(item, translator, season, ep_idx)


# ── Router ────────────────────────────────────────────────────────────────────

def router(paramstring):
    # keep_blank_values: translator="" is a valid value (means "no
    # translator recorded, use the page's default/only track") and must
    # not be dropped from the parsed dict.
    p = dict(parse_qsl(paramstring, keep_blank_values=True))
    action = p.get("action")

    if not action:
        show_categories()
    elif action == "list_items":
        show_items(p["category"])
    elif action == "search":
        show_search(p["category"])
    elif action == "list_translators":
        show_translators(int(p["id"]))
    elif action == "list_qualities":
        show_qualities(int(p["id"]), p["translator"])
    elif action == "list_seasons":
        show_seasons(int(p["id"]), p["translator"])
    elif action == "list_episodes":
        show_episodes(int(p["id"]), p["translator"], p["season"])
    elif action == "list_episode_qualities":
        show_episode_qualities(int(p["id"]), p["translator"], p["season"], p["episode"])
    elif action == "list_kinogo_ep_qualities":
        show_kinogo_ep_qualities(int(p["id"]), p["translator"], p["season"], p["ep_idx"])
    elif action == "play":
        play_video(p["video_url"], referer=p.get("referer"))


if __name__ == "__main__":
    router(sys.argv[2][1:])
